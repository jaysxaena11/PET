import { createHash } from "node:crypto";

export type Status = "created" | "in_progress" | "submitted" | "scored";
export type Marking = { positive: number; negative: number };
export type Q = { id: string; correctOptionId: string; optionIds: string[]; subject: string };
export type Session = {
  status: Status; startedAt?: number; durationMs: number; marking: Marking;
  questions: Q[]; responses: Record<string, { optionId: string | null; marked: boolean }>;
  result?: Result;
};
export type Result = {
  score: number; attempted: number; correct: number; incorrect: number; unanswered: number;
  accuracy: number; bySubject: Record<string, { correct: number; incorrect: number; unanswered: number }>;
};

const NEXT: Record<Status, Status | null> = { created: "in_progress", in_progress: "submitted", submitted: "scored", scored: null };
export function transition(s: Session, to: Status) {
  if (NEXT[s.status] !== to) throw new Error(`illegal transition ${s.status} -> ${to}`);
  s.status = to;
}
export function start(s: Session, now: number) { transition(s, "in_progress"); s.startedAt = now; }
export const isExpired = (s: Session, now: number) => s.startedAt !== undefined && now >= s.startedAt + s.durationMs;
export const remainingMs = (s: Session, now: number) => Math.max(0, (s.startedAt ?? now) + s.durationMs - now);

/** Server-side answer save. Rejects options not belonging to the question and writes after expiry. */
export function respond(s: Session, qid: string, optionId: string | null, now: number, marked = false) {
  if (s.status !== "in_progress") throw new Error("session not in progress");
  if (isExpired(s, now)) throw new Error("session expired");
  const q = s.questions.find((x) => x.id === qid);
  if (!q) throw new Error("unknown question");
  if (optionId !== null && !q.optionIds.includes(optionId)) throw new Error("option does not belong to question");
  s.responses[qid] = { optionId, marked };
}

export type PaletteState = "unanswered" | "answered" | "marked" | "answered_marked";
export function paletteState(s: Session, qid: string): PaletteState {
  const r = s.responses[qid]; const a = !!r?.optionId, m = !!r?.marked;
  return a && m ? "answered_marked" : m ? "marked" : a ? "answered" : "unanswered";
}

export function score(questions: Q[], responses: Session["responses"], m: Marking): Result {
  let correct = 0, incorrect = 0; const bySubject: Result["bySubject"] = {};
  for (const q of questions) {
    const b = (bySubject[q.subject] ??= { correct: 0, incorrect: 0, unanswered: 0 });
    const a = responses[q.id]?.optionId;
    if (!a) b.unanswered++; else if (a === q.correctOptionId) { correct++; b.correct++; } else { incorrect++; b.incorrect++; }
  }
  const attempted = correct + incorrect;
  const raw = correct * m.positive - incorrect * m.negative;
  return { score: Math.round(raw * 100) / 100, attempted, correct, incorrect, unanswered: questions.length - attempted,
    accuracy: attempted ? correct / attempted : 0, bySubject };
}

/** Idempotent: a second call returns the stored result and never re-scores. */
export function submit(s: Session, _now: number): Result {
  if (s.status === "scored" && s.result) return s.result;
  if (s.status === "created") throw new Error("not started");
  if (s.status === "in_progress") transition(s, "submitted");
  s.result = score(s.questions, s.responses, s.marking);
  transition(s, "scored");
  return s.result;
}
export function autoSubmitIfExpired(s: Session, now: number) { return isExpired(s, now) && s.status === "in_progress" ? submit(s, now) : s.result ?? null; }

// ---- Duplicate control ----
export const normalize = (t: string) => t.normalize("NFKC").toLowerCase().replace(/[^\p{L}\p{N}\p{M}\s]/gu, " ").replace(/\s+/g, " ").trim();
export function fingerprint(text: string, options: string[]) {
  return createHash("sha256").update(normalize(text) + "|" + options.map(normalize).sort().join("|")).digest("hex");
}
const grams = (t: string) => { const n = normalize(t).replace(/\s/g, ""); const g = new Set<string>(); for (let i = 0; i < n.length - 2; i++) g.add(n.slice(i, i + 3)); return g; };
export function similarity(a: string, b: string) {
  const A = grams(a), B = grams(b); if (!A.size || !B.size) return 0;
  let i = 0; for (const x of A) if (B.has(x)) i++; return i / (A.size + B.size - i);
}
export type Verdict = "exact" | "near" | "unique";
export function checkDuplicate(c: { text: string; options: string[] }, existing: { text: string; options: string[] }[], nearThreshold = 0.8): Verdict {
  const fp = fingerprint(c.text, c.options); let near = false;
  for (const e of existing) {
    if (fingerprint(e.text, e.options) === fp) return "exact";
    if (similarity(c.text + " " + c.options.join(" "), e.text + " " + e.options.join(" ")) >= nearThreshold) near = true;
  }
  return near ? "near" : "unique";
}

/** Validates an AI-generated MCQ before it may enter the review queue. */
export function validateGenerated(q: any): string[] {
  const e: string[] = [];
  if (!q?.text_en && !q?.text_hi) e.push("missing question text");
  if (!Array.isArray(q?.options) || q.options.length !== 4) e.push("must have exactly 4 options");
  else if (q.options.filter((o: any) => o.is_correct).length !== 1) e.push("must have exactly one correct option");
  if (!q?.explanation) e.push("missing explanation");
  for (const k of ["subject", "topic", "difficulty"]) if (!q?.[k]) e.push(`missing ${k}`);
  return e;
}
