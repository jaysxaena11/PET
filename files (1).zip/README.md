# PET Master 2026 — Phase 1
Run tests: `node --test tests/engine.test.ts` (Node >= 22.18).
Status: see chat report. Syllabus, weights and marking are configuration, NOT verified against the 2026 notification.
