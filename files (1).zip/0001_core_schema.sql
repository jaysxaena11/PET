-- UNTESTED: written without a Postgres instance. Run against a Supabase dev project first.
create extension if not exists pgcrypto;
create type user_role as enum ('student','admin');
create type q_status as enum ('draft','pending_review','approved','published','rejected','archived');
create type q_source as enum ('previous_year','ai_practice','predicted_pattern','manual');
create type session_status as enum ('created','in_progress','submitted','scored');
create type verification as enum ('unverified','pending','verified','rejected');

create table profiles (id uuid primary key references auth.users on delete cascade, display_name text,
  preferred_language text not null default 'en' check (preferred_language in ('en','hi')),
  role user_role not null default 'student', created_at timestamptz not null default now(), updated_at timestamptz not null default now());

create table syllabus_versions (id uuid primary key default gen_random_uuid(), label text not null unique,
  verified_against_notification boolean not null default false, is_active boolean not null default false, created_at timestamptz default now());
create table subjects (id uuid primary key default gen_random_uuid(), syllabus_version_id uuid not null references syllabus_versions,
  slug text not null, name_en text not null, name_hi text, weight numeric, question_count int, unique (syllabus_version_id, slug));
create table topics (id uuid primary key default gen_random_uuid(), subject_id uuid not null references subjects on delete cascade,
  parent_id uuid references topics, name_en text not null, name_hi text);

create table question_sources (id uuid primary key default gen_random_uuid(), paper_name text, exam_year int, exam_date date, shift text,
  source_url text, document_ref text, verification verification not null default 'unverified', created_at timestamptz default now());
create table questions (id uuid primary key default gen_random_uuid(), subject_id uuid references subjects, topic_id uuid references topics,
  source_type q_source not null, source_id uuid references question_sources, status q_status not null default 'draft',
  text_en text, text_hi text, hi_verified boolean not null default false, explanation_en text, explanation_hi text,
  difficulty text check (difficulty in ('easy','medium','hard')), fingerprint text not null, answer_key_ref text,
  paper_position int, created_at timestamptz default now(), updated_at timestamptz default now(),
  check (text_en is not null or text_hi is not null),
  check (source_type <> 'previous_year' or status not in ('approved','published') or source_id is not null));
create unique index questions_fp_uq on questions (fingerprint) where status <> 'archived' and status <> 'rejected';
create index questions_pool_idx on questions (subject_id, topic_id, status);
create table question_options (id uuid primary key default gen_random_uuid(), question_id uuid not null references questions on delete cascade,
  position int not null check (position between 1 and 4), text_en text, text_hi text, is_correct boolean not null default false,
  unique (question_id, position));
create unique index one_correct_per_q on question_options (question_id) where is_correct;

create table test_templates (id uuid primary key default gen_random_uuid(), kind text not null check (kind in ('full_mock','previous_year','topic_practice','custom')),
  name text not null, syllabus_version_id uuid references syllabus_versions, duration_seconds int not null,
  positive_marks numeric not null, negative_marks numeric not null, blueprint jsonb not null default '{}', source_id uuid references question_sources,
  is_published boolean not null default false);
create table test_sessions (id uuid primary key default gen_random_uuid(), user_id uuid not null references profiles, template_id uuid references test_templates,
  status session_status not null default 'created', started_at timestamptz, ends_at timestamptz, submitted_at timestamptz,
  duration_seconds int not null, positive_marks numeric not null, negative_marks numeric not null, created_at timestamptz default now());
create index sessions_user_idx on test_sessions (user_id, created_at desc);
create table session_questions (session_id uuid references test_sessions on delete cascade, position int, question_id uuid not null references questions,
  snapshot jsonb not null,  -- text, options in fixed order, correct option id, subject: immutable
  primary key (session_id, position), unique (session_id, question_id));
create table student_responses (session_id uuid, position int, selected_option_id uuid, marked boolean not null default false,
  status text not null default 'unanswered', answered_at timestamptz default now(), primary key (session_id, position),
  foreign key (session_id, position) references session_questions on delete cascade);
create table test_results (session_id uuid primary key references test_sessions on delete cascade, score numeric not null, attempted int, correct int,
  incorrect int, unanswered int, accuracy numeric, time_spent_seconds int, breakdown jsonb not null default '{}', scored_at timestamptz default now());
create table bookmarks (user_id uuid references profiles on delete cascade, question_id uuid references questions on delete cascade,
  created_at timestamptz default now(), primary key (user_id, question_id));
create table question_reports (id uuid primary key default gen_random_uuid(), question_id uuid not null references questions, user_id uuid not null references profiles,
  reason text not null, status text not null default 'open', created_at timestamptz default now());
create table generation_jobs (id uuid primary key default gen_random_uuid(), user_id uuid references profiles, status text not null default 'queued',
  request jsonb not null, input_tokens int default 0, output_tokens int default 0, est_cost_usd numeric default 0, retry_count int not null default 0,
  error text, created_at timestamptz default now(), finished_at timestamptz);
create table admin_audit_logs (id bigint generated always as identity primary key, admin_id uuid not null references profiles, entity text not null,
  entity_id uuid, action text not null, before jsonb, after jsonb, created_at timestamptz default now());

-- Row Level Security
create function is_admin() returns boolean language sql stable security definer set search_path = public
  as $$ select exists (select 1 from profiles where id = auth.uid() and role = 'admin') $$;
alter table profiles enable row level security; alter table test_sessions enable row level security;
alter table session_questions enable row level security; alter table student_responses enable row level security;
alter table test_results enable row level security; alter table bookmarks enable row level security;
alter table question_reports enable row level security; alter table questions enable row level security;
alter table question_options enable row level security; alter table question_sources enable row level security;
alter table test_templates enable row level security; alter table generation_jobs enable row level security;
alter table admin_audit_logs enable row level security; alter table subjects enable row level security; alter table topics enable row level security;
alter table syllabus_versions enable row level security;

create policy p_self_read on profiles for select using (id = auth.uid());
create policy p_self_update on profiles for update using (id = auth.uid()) with check (id = auth.uid() and role = (select role from profiles where id = auth.uid()));
create policy s_own on test_sessions for select using (user_id = auth.uid());       -- writes happen only via server (service role)
create policy sq_own on session_questions for select using (exists (select 1 from test_sessions s where s.id = session_id and s.user_id = auth.uid()));
create policy r_own on student_responses for select using (exists (select 1 from test_sessions s where s.id = session_id and s.user_id = auth.uid()));
create policy res_own on test_results for select using (exists (select 1 from test_sessions s where s.id = session_id and s.user_id = auth.uid()));
create policy b_own on bookmarks for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy rep_ins on question_reports for insert with check (user_id = auth.uid());
create policy rep_own on question_reports for select using (user_id = auth.uid() or is_admin());
create policy q_pub on questions for select using (status = 'published' or is_admin());
create policy qo_pub on question_options for select using (exists (select 1 from questions q where q.id = question_id and q.status = 'published'));
create policy ref_read on subjects for select using (true); create policy ref_read2 on topics for select using (true);
create policy ref_read3 on syllabus_versions for select using (is_active or is_admin());
create policy tt_pub on test_templates for select using (is_published or is_admin());
create policy src_pub on question_sources for select using (verification = 'verified' or is_admin());
create policy audit_admin on admin_audit_logs for select using (is_admin());
-- NOTE: students get no direct write on sessions/responses/questions; the API uses the service role.
-- Because question_options.is_correct is readable on published rows, serve exam questions from a server route / view that omits it (TODO Phase 2).
