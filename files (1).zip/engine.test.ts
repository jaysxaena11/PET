import { test } from "node:test"; import assert from "node:assert/strict";
import * as E from "../lib/engine.ts";
const mk = (): E.Session => ({ status: "created", durationMs: 60_000, marking: { positive: 1, negative: 0.25 },
  questions: ["a", "b", "c", "d"].map((id, i) => ({ id, correctOptionId: id + "1", optionIds: [id + "1", id + "2", id + "3", id + "4"], subject: i < 2 ? "math" : "gk" })),
  responses: {} });
test("scoring: correct, incorrect, unanswered", () => {
  const s = mk(); E.start(s, 0);
  E.respond(s, "a", "a1", 1); E.respond(s, "b", "b2", 2); E.respond(s, "c", "c1", 3);
  const r = E.submit(s, 4);
  assert.equal(r.score, 1.75); assert.equal(r.correct, 2); assert.equal(r.incorrect, 1); assert.equal(r.unanswered, 1);
  assert.deepEqual(r.bySubject.math, { correct: 1, incorrect: 1, unanswered: 0 });
});
test("rejects option from another question", () => { const s = mk(); E.start(s, 0); assert.throws(() => E.respond(s, "a", "b1", 1)); });
test("timer expiry blocks writes and auto-submits", () => {
  const s = mk(); E.start(s, 0); E.respond(s, "a", "a1", 10);
  assert.throws(() => E.respond(s, "b", "b1", 60_000), /expired/);
  assert.equal(E.autoSubmitIfExpired(s, 60_001)!.score, 1); assert.equal(s.status, "scored");
});
test("idempotent submit", () => {
  const s = mk(); E.start(s, 0); E.respond(s, "a", "a1", 1);
  const r1 = E.submit(s, 2), r2 = E.submit(s, 3); assert.equal(r1, r2);
});
test("illegal transitions and writes before start", () => {
  const s = mk(); assert.throws(() => E.respond(s, "a", "a1", 0)); assert.throws(() => E.submit(s, 0));
  E.start(s, 0); assert.throws(() => E.start(s, 1));
});
test("palette states + clear response", () => {
  const s = mk(); E.start(s, 0);
  E.respond(s, "a", "a1", 1, true); E.respond(s, "b", "b1", 1); E.respond(s, "c", null, 1, true);
  assert.deepEqual(["a", "b", "c", "d"].map((q) => E.paletteState(s, q)), ["answered_marked", "answered", "marked", "unanswered"]);
  E.respond(s, "b", null, 2); assert.equal(E.paletteState(s, "b"), "unanswered");
});
test("resume: remaining time derives from server start time", () => {
  const s = mk(); E.start(s, 1000); assert.equal(E.remainingMs(s, 21_000), 40_000);
});
test("duplicates: exact, near, unique (Hindi too)", () => {
  const bank = [{ text: "भारत की राजधानी क्या है?", options: ["दिल्ली", "मुंबई", "चेन्नई", "कोलकाता"] },
    { text: "What is the capital of India?", options: ["Delhi", "Mumbai", "Chennai", "Kolkata"] }];
  assert.equal(E.checkDuplicate({ text: "भारत की राजधानी क्या है", options: ["कोलकाता", "दिल्ली", "मुंबई", "चेन्नई"] }, bank), "exact");
  assert.equal(E.checkDuplicate({ text: "What is the capital city of India?", options: ["Delhi", "Mumbai", "Chennai", "Kolkata"] }, bank), "near");
  assert.equal(E.checkDuplicate({ text: "Who wrote the Constitution draft?", options: ["Ambedkar", "Nehru", "Patel", "Gandhi"] }, bank), "unique");
});
test("generated-question validation", () => {
  const ok = { text_en: "q", subject: "s", topic: "t", difficulty: "easy", explanation: "e", options: [{ is_correct: true }, {}, {}, {}] };
  assert.deepEqual(E.validateGenerated(ok), []);
  assert.ok(E.validateGenerated({ ...ok, options: [{ is_correct: true }, { is_correct: true }, {}, {}] }).length);
  assert.ok(E.validateGenerated({ ...ok, options: [{ is_correct: true }] }).length);
});
